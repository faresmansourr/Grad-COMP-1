# Load necessary libraries
library(limma)
library(ggplot2)
library(dplyr)
# Load data

library(readxl)
metabolomics <- read_excel("D:/grad/Metabolomics.xlsx")
View(metabolomics)

metadata <- read_excel("D:/grad/Metadata .xlsx")
View(metadata)


# Ensure Patient_ID exists in both datasets
if(!"Patient_ID" %in% colnames(metabolomics)) {
  stop("Patient_ID column is missing in metabolomics data.")
}

# Merge metadata with metabolomics data
coldata <- metadata %>%
  select(Patient_ID, ADAS.group) %>%
  inner_join(metabolomics, by = "Patient_ID")

# Convert ADAS.group to a factor
coldata$ADAS.group <- as.factor(coldata$ADAS.group)

# Prepare expression matrix (Ensure it's numeric)
expr_matrix <- coldata %>%
  select(-c(Patient_ID, ADAS.group)) %>%
  mutate_all(as.numeric) %>%
  as.matrix()

# Check for missing values
if (any(is.na(expr_matrix))) {
  expr_matrix[is.na(expr_matrix)] <- 0  # Replace NA with 0 (or impute values)
}

# Ensure genes/metabolites are in rows, samples in columns
if(nrow(expr_matrix) < ncol(expr_matrix)) {
  expr_matrix <- t(expr_matrix)
}

# Design matrix
design <- model.matrix(~ ADAS.group, data = coldata)

# Fit the model
fit <- lmFit(expr_matrix, design)
fit <- eBayes(fit)

# Get results
coef_name <- colnames(design)[2]  # Extract the correct coefficient name
results <- topTable(fit, coef = coef_name, adjust = "fdr", number = Inf)

# Plot Volcano Plot
volcano <- ggplot(results, aes(x = logFC, y = -log10(P.Value))) +
  geom_point(alpha = 0.5) +
  labs(title = "Volcano plot", x = "Log Fold Change", y = "-Log10 P-value") +
  theme_minimal()
print(volcano)

# Boxplot for normalized metabolomics data
boxplot(log2(expr_matrix + 1), 
        main = "Boxplot of  Metabolomics Data", 
        xlab = "Samples", 
        ylab = "Log2 Intensity", 
        las = 2, 
        col = rainbow(ncol(expr_matrix)))

# Load required library
library(factoextra)

# Identify and remove features (rows) with zero variance
zero_var_rows <- apply(expr_matrix, 1, function(x) var(x) == 0)
expr_matrix_filtered <- expr_matrix[!zero_var_rows, ]  # Remove zero-variance rows

# Identify and remove samples (columns) with zero variance
zero_var_cols <- apply(expr_matrix_filtered, 2, function(x) var(x) == 0)
expr_matrix_filtered <- expr_matrix_filtered[, !zero_var_cols]  # Remove zero-variance columns

# Check if there are enough features and samples for PCA
if (nrow(expr_matrix_filtered) > 1 && ncol(expr_matrix_filtered) > 1) {
  # Perform PCA
  pca_res <- prcomp(t(expr_matrix_filtered), scale. = TRUE)
  
  # Plot PCA with ADAS.group as color
  fviz_pca_ind(pca_res, 
               col.ind = coldata$ADAS.group,  # Color by ADAS group
               addEllipses = TRUE, 
               repel = TRUE,
               legend.title = "ADAS Group")
} else {
  print("PCA cannot be performed: Not enough variable features after filtering.")
}

########

# Ensure sample names in coldata and expr_matrix match
if (!all(coldata$Patient_ID %in% colnames(expr_matrix))) {
  stop("Mismatch: Some Patient_IDs in metadata are not in the expression matrix!")
}

# Select only matching samples in coldata
annotation_col <- coldata %>%
  filter(Patient_ID %in% colnames(expr_matrix)) %>%
  select(ADAS.group)

# Ensure rownames(annotation_col) matches colnames(expr_matrix)
rownames(annotation_col) <- colnames(expr_matrix)

# Generate heatmap
pheatmap(expr_matrix, annotation_col = annotation_col)


# Save results
write.csv(results, "D:/grad/Metabolomics_DE_Result1s.csv", row.names = TRUE)