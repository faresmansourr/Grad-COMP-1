mbSet<-Init.mbSetObj()
mbSet<-SetModuleType(mbSet, "tsea")
taxa.vec<-scan("path_to_file");
mbSet<-Setup.MapData(mbSet, taxa.vec);
mbSet<-CrossReferencing(mbSet, "mixed");
mbSet<-SetTaxonSetLib(mbSet, "host_int");
mbSet<-CalculateHyperScore(mbSet);
