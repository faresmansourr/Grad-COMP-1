# Load necessary libraries
suppressMessages({
  library(limma)
  library(ggplot2)
  library(dplyr)
  library(readxl)
  library(pheatmap)
  library(FactoMineR)
  library(factoextra)
})

# Define file paths
S_metagenomics_file <- "D:/grad/Saliva_Metagenomics.xlsx"
S_metadata_file <- "D:/grad/Metadata .xlsx"

# Load Data
S_metagenomics_data <- read_excel(S_metagenomics_file)
metadata <- read_excel(S_metadata_file)

# Ensure matching sample IDs between metadata and metagenomics data
common_samples <- intersect(metadata$Patient_ID, S_metagenomics_data$Patient_ID)
metadata <- metadata %>% filter(Patient_ID %in% common_samples)
S_metagenomics_data <- S_metagenomics_data %>% filter(Patient_ID %in% common_samples)

# Set Patient_ID as row names
rownames(metadata) <- metadata$Patient_ID
rownames(S_metagenomics_data) <- S_metagenomics_data$Patient_ID
S_metagenomics_data <- S_metagenomics_data[, -1]  # Remove Patient_ID column

# Ensure samples are in columns, features (taxa) in rows
if (nrow(S_metagenomics_data) < ncol(S_metagenomics_data)) {
  S_metagenomics_data <- t(S_metagenomics_data)
}

# Convert metadata grouping variable to a factor
metadata$ADAS.group <- as.factor(metadata$ADAS.group)

# Design matrix for limma
design <- model.matrix(~ ADAS.group, data = metadata)

# Fit the linear model using limma
fit <- lmFit(S_metagenomics_data, design)
fit <- eBayes(fit)

# Get differentially abundant taxa
coef_name <- colnames(design)[2]  # Extract the correct coefficient name
results <- topTable(fit, coef = coef_name, adjust = "fdr", number = Inf)

# PCA Analysis
pca_res <- prcomp(t(S_metagenomics_data), scale. = TRUE)
fviz_pca_ind(pca_res, col.ind = metadata$ADAS.group, addEllipses = TRUE)

# Boxplot
boxplot(log2(S_metagenomics_data + 1), main="Boxplot of Normalized Counts")

# Heatmap
pheatmap(S_metagenomics_data, annotation_col = metadata)


# Volcano Plot
volcano_data <- as.data.frame(results)
volcano_data$Significance <- ifelse(volcano_data$adj.P.Val < 0.05, "Significant", "Not Significant")

ggplot(volcano_data, aes(x=logFC, y=-log10(adj.P.Val), color=Significance)) +
  geom_point() + theme_minimal() +
  labs(title = "Volcano Plot - Saliva Metagenomics", x = "Log Fold Change", y = "-Log10 Adjusted P-value")

# Save results
write.csv(results, "D:/grad/Saliva_Metagenomics_DE_Results.csv", row.names = TRUE)
