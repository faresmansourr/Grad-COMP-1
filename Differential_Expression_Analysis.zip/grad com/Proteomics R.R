# Load necessary libraries
library(limma)
library(ggplot2)
library(dplyr)


library(readxl)
metadata <- read_excel("D:/grad/Metadata .xlsx")
View(metadata)


library(readxl)
proteomics <- read_excel("D:/grad/Proteomics.xlsx")
View(proteomics)


# Ensure Patient_ID is in both datasets
if(!"Patient_ID" %in% colnames(proteomics)) {
  stop("Patient_ID column is missing in proteomics data.")
}

# Merge the metadata
coldata <- metadata %>% 
  select(Patient_ID, ADAS.group) %>% 
  inner_join(proteomics, by = "Patient_ID")

# Convert data to appropriate format for limma
design <- model.matrix(~ ADAS.group, coldata)
y <- t(proteomics)  # Transposing for limma

# Convert ADAS.group to a factor
coldata$ADAS.group <- as.factor(coldata$ADAS.group)

# Prepare expression matrix (remove non-numeric columns)
expr_matrix <- coldata %>% 
  select(-c(Patient_ID, ADAS.group)) %>%  # Remove non-numeric columns
  mutate_all(as.numeric) %>%  # Ensure all columns are numeric
  as.matrix()

# Check for missing values
if (any(is.na(expr_matrix))) {
  expr_matrix[is.na(expr_matrix)] <- 0  # Replace NA with 0 (or use imputation)
}

# Ensure genes are in rows, samples in columns
if(nrow(expr_matrix) < ncol(expr_matrix)) {
  expr_matrix <- t(expr_matrix)
}

# Design matrix
design <- model.matrix(~ ADAS.group, data = coldata)


# Fit the model
fit <- lmFit(expr_matrix, design)
fit <- eBayes(fit)



# Get results
coef_name <- colnames(design)[2]  # Extract the correct coefficient name
results <- topTable(fit, coef = coef_name, adjust = "fdr", number = Inf)


# Plot Volcano Plot
volcano <- ggplot(results, aes(x = logFC, y = -log10(P.Value))) +
  geom_point(alpha = 0.5) +
  labs(title = "Volcano plot", x = "Log Fold Change", y = "-Log10 P-value") +
  theme_minimal()
print(volcano)

# Load required library
library(ggplot2)

# Convert expression matrix to long format for ggplot
expr_long <- as.data.frame(expr_matrix)
expr_long$Protein <- rownames(expr_long)  # Add protein names
expr_melt <- reshape2::melt(expr_long, id.vars = "Protein")


# Boxplot for proteomics data
boxplot(log2(expr_matrix + 1), 
        main = "Boxplot of  Proteomics Data", 
        xlab = "Samples", 
        ylab = "Log2 Intensity", 
        las = 2,  # Rotate x-axis labels
        col = rainbow(ncol(expr_matrix)), 
        outline = FALSE)  # Remove outliers for better visualization



# Load required library
library(factoextra)

# Remove features (rows) with zero variance
zero_var_rows <- apply(expr_matrix, 1, function(x) var(x, na.rm = TRUE) == 0)
expr_matrix_filtered <- expr_matrix[!zero_var_rows, , drop = FALSE]  

# Remove samples (columns) with zero variance
zero_var_cols <- apply(expr_matrix_filtered, 2, function(x) var(x, na.rm = TRUE) == 0)
expr_matrix_filtered <- expr_matrix_filtered[, !zero_var_cols, drop = FALSE]  

# Check if there are enough features and samples for PCA
if (nrow(expr_matrix_filtered) > 1 && ncol(expr_matrix_filtered) > 1) {
  
  # Perform PCA
  pca_res <- prcomp(t(expr_matrix_filtered), scale. = TRUE, center = TRUE)
  
  # PCA Plot with ADAS.group as color
  fviz_pca_ind(pca_res, 
               geom = "point",  # Use points instead of text
               col.ind = coldata$ADAS.group,  # Color by ADAS group
               addEllipses = TRUE,  # Confidence ellipses for groups
               repel = TRUE,  # Avoid label overlap
               palette = "jco",  # Improved color scheme
               legend.title = "ADAS Group") +
    ggtitle("PCA of Proteomics Data") + theme_minimal()
  
} else {
  print("PCA cannot be performed: Not enough variable features after filtering.")
}

# Save results
write.csv(results, "D:/grad/Proteomics_DE_Results1.csv", row.names = TRUE)
write.csv(results, "D:/grad/Proteomics_DE_Results1.csv", row.names=TRUE)